#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "matrix_keypad.h"

extern char main_f;
extern char menu_f;

//function to handle the menu
void menu(char key)
{
    //logic for menu
    // Array of menu items as strings
    unsigned char *menup[] = {"View log       ", "Clear log      ", "Download log   ", "Set time       ", "Change Password"};
    static unsigned int idx=0;
    static unsigned int i = 0; 
    static unsigned int flag = 0;
    // Display an (*) on the selected line
    if(i == 1)
    {
        clcd_print("*",LINE2(0));
    }
    else
    {
        clcd_print("*",LINE1(0));
    }
    // Display the current and next menu items
    clcd_print(menup[idx],LINE1(1));
    clcd_print(menup[idx+1],LINE2(1));
    //Move down the menu
    if(key == MK_SW12)
    {
        
        if(idx < 3 && i != 0)
        {
           idx++;
        }
        i = 1;
        CLEAR_DISP_SCREEN;
    }
    //Move up the menu
    else if(key == MK_SW11)
    {
        if(idx > 0 && i != 1)
        {
           idx--;
        }
        i = 0;
        CLEAR_DISP_SCREEN;
       
    }
    // Select the menu item (MK_LONG_SW11 pressed)
    else if(key == MK_LONG_SW11)
    {
        main_f = MENU_ENTER;
        if((idx+i) == VIEWLOG)
        {
            menu_f = VIEWLOG;
        }
        else if((idx+i) == DOWNLOADLOG)
        {
            menu_f = DOWNLOADLOG;
        }
        else if((idx+i) == CLEARLOG)
        {
            menu_f = CLEARLOG;
        }
        else if((idx+i) == SETTIME)
        {
            menu_f = SETTIME;
        }
        else if((idx+i) == CHANGEPASS)
        {
            menu_f = CHANGEPASS;
        }
        CLEAR_DISP_SCREEN;
    }
    else if(key == MK_LONG_SW12)
    {
        main_f = DASHBOARD;
        CLEAR_DISP_SCREEN;
    }   
}