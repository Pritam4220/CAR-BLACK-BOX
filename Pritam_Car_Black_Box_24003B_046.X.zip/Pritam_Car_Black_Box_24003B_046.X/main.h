#ifndef MAIN
#define MAIN

#define DASHBOARD               0
#define PASSWORD                1
#define MENU                    2
#define MENU_ENTER              3
#define VIEWLOG                 0
#define DOWNLOADLOG             2
#define CLEARLOG                1
#define SETTIME                 3
#define CHANGEPASS              4

void dashboard();               
void store_event();
void password(char key);
void menu(char key);
void view_log(char key);
void download_log();
void clear_log(char key);
void settime(char key);
void change_pass(char key);
void new_passwd(char key);
void cnfm_pass(char key);
void get_time(void);
void init_config();
int my_sprintf(char *buffer, const char *format, ...);
void inc_value();
void blink_field();
void save_time();
void display_logs(unsigned char addr);
void download_display(unsigned char addr);
#endif