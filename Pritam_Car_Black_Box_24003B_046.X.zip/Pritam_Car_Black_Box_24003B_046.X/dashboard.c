#include <xc.h>
#include "main.h"
#include "clcd.h"
extern unsigned char real_time[9];

void dashboard(unsigned char gear[], unsigned int sp_val)
{
    clcd_print("TIME",LINE1(2));
    clcd_print(real_time,LINE2(0));
    clcd_print("EV",LINE1(10));
    clcd_print(gear,LINE2(10));     
    clcd_print("SP",LINE1(14));
    
    //Here we are displaying the speed of the car
    clcd_putch('0' + (sp_val % 10), LINE2(15));     
    clcd_putch('0' + ((sp_val/10) % 10), LINE2(14));     
}