#ifndef TIMER_H
#define TIMER_H

void init_timer0(void);

#endif