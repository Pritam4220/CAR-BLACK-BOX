#include <xc.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "external_eeprom.h"
extern char main_f;
extern char addr;
extern unsigned int clr_flag;
extern unsigned int save_log;
extern unsigned int store_count;
extern unsigned char eeprom_add;
extern unsigned int dwnld_flag;

void clear_log(char key) 
{
    //logic for clear
    //Here i have loop for only 100 times because we are store only 100 bytes
    for (unsigned int i = 0; i < 100; i++) 
    {
        write_external_eeprom(i, 0xFF);
    }
    
    addr = 0x00;
    clcd_print("LOG CLEARED", LINE1(0));
    clcd_print("Successfully", LINE2(0));
    for (unsigned long int k = 500000; k--;);
    
    main_f = MENU;
    CLEAR_DISP_SCREEN;
    clr_flag = 1;
    save_log = 0;
    store_count = 0;
    dwnld_flag = 1;
    eeprom_add = EEPROM_ADD;
}