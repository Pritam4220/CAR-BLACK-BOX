#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "ds1307.h"
#include "matrix_keypad.h"

extern char hour,min,sec1;
extern char main_f;
extern char field_pos;
char blink_pos=0;
unsigned int blink_timer=0;
extern char set_time_flag;
unsigned char updated_time;

// Function to set the time using a matrix keypad
void settime(char key)
{
    clcd_print(" SET TIME LOG", LINE1(0));
       // Increase the selected time field (seconds, minutes, or hours) when MK_SW11 is pressed
       if(key== MK_SW11)
        {
                if(field_pos==0)
                {
                    sec1++;
                    if(sec1==60)
                        sec1=0;
                }
                else if(field_pos==1)
                {
                    min++;
                    if(min==60)
                        min=0;
                }
                else if(field_pos==2)
                {
                    hour++;
                    if(hour==24)
                        hour=0;
                }
            
        }
       // Move to the next time field (seconds -> minutes -> hours) when MK_SW12 is pressed
       else if(key == MK_SW12)
       {
           field_pos++;
           if(field_pos==3)
               field_pos=0;
       }
       // Save the updated time to the RTC and return to the main menu when MK_LONG_SW11 is pressed
       else if(key== MK_LONG_SW11)
       {
           set_time_flag=0;
           // Update the RTC with the new time 
           updated_time=((hour/10)<<4)|(hour%10);
           write_ds1307(HOUR_ADDR,updated_time);
           
           updated_time=((min/10)<<4)|(min%10);
           write_ds1307(MIN_ADDR,updated_time);
           
           updated_time=((sec1/10)<<4)|(sec1%10);
           write_ds1307(SEC_ADDR,updated_time);
                
           main_f = MENU;
           CLEAR_DISP_SCREEN;   
       }
       // Cancel the time setting and return to the main menu when MK_LONG_SW12 is pressed
       else if(key == MK_LONG_SW12)
       {
           set_time_flag=0;
	       write_ds1307(SEC_ADDR,(read_ds1307(SEC_ADDR))& 0x7F); 
           main_f = MENU;
       }
       // Blink the currently selected field for visual feedback
       if (blink_timer < 250) 
        {
            // Display the current time on the second line of the CLCD
            clcd_putch((hour/10)+'0',LINE2(1));
            clcd_putch((hour%10)+'0',LINE2(2));
            clcd_putch(':',LINE2(3));
            clcd_putch((min/10)+'0',LINE2(4));
            clcd_putch((min%10)+'0',LINE2(5));
            clcd_putch(':',LINE2(6));
            clcd_putch((sec1/10)+'0',LINE2(7));
            clcd_putch((sec1%10)+'0',LINE2(8)); 
        } 
        else if (blink_timer < 500)
        {
            // Clear the selected field to create the blinking effect
            //Blink seconds
            if(field_pos==0)
            {
               clcd_putch(' ',LINE2(7));
               clcd_putch(' ',LINE2(8));
            }
            //Blink minutes
            else  if(field_pos==1)
            {
               clcd_putch(' ',LINE2(4));
               clcd_putch(' ',LINE2(5));
            }
            //Blink hours
            else  if(field_pos==2)
            {
                clcd_putch(' ',LINE2(1));
                clcd_putch(' ',LINE2(2));
            }
                
        } 
        else
        {
            blink_timer = 0;
        }
       blink_timer++; 
}