#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "external_eeprom.h"

unsigned int save_log = 0;
unsigned int store_count = 0;
unsigned char eeprom_add = EEPROM_ADD;
unsigned char event_count =0;
extern char event[20];

// Function to store an event log in external EEPROM
void store_event(char *real_time,unsigned char *GR,unsigned int spd)
{
    //logic for storing 
    CLEAR_DISP_SCREEN;
    // Increment the log counter for the number of saved logs
    save_log++; 
    // If 10 events have been stored, reset the event count and EEPROM address
    if(event_count>=10)
    {
        event_count=0;
        eeprom_add=0x00;
    }
    //Here Store the time part of the event, skipping the ':' characters
    for(int i=0;i<=7;i++)
    {
        //Here i skip the ':'
        if(i == 2 || i == 5)
        {
            continue;
        }
        // Store each digit of the time
        write_external_eeprom(eeprom_add++,real_time[i]);
    }
    // Store the gear status (GR[0] and GR[1]) in the EEPROM
    write_external_eeprom(eeprom_add++,GR[0]);
    write_external_eeprom(eeprom_add++,GR[1]);
    
    // Store the speed in the EEPROM, converting it to characters
    write_external_eeprom(eeprom_add++,('0'+((spd/10)%10)));
    write_external_eeprom(eeprom_add++,('0'+((spd%10))));  
    
    event_count++;
    store_count++;
}