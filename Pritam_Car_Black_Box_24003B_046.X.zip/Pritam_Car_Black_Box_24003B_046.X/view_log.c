#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "external_eeprom.h"
#include "matrix_keypad.h"
#define EVENT_SIZE 10

unsigned int clr_flag = 0;
unsigned short view_flag,count;
unsigned char addr = 0x00;
extern unsigned short store_count;
extern unsigned char main_f, menu_f;

//Function to view the logs
void view_log(char key)
{
    //logic of view log
    //Here we check if there are any stored logs to view
    if(store_count != 0)
    {
        if(!view_flag)
        {
            if(store_count > 10)
            {
                addr = addr + ((store_count%10)*10);
                view_flag = 1;
            }
        }
        // Scroll down to the next log entry if MK_SW11 is pressed
        if (key == MK_SW11 && (count < (store_count - 1)) && count != 9) 
        {
            if(addr < 90)
            {
                //Here move to the next log entry
                addr = addr + 10;
            }
            else
            {
                addr = 0x00;
            }
            //increment the log counter
            count++;
        }
        // Scroll up to the previous log entry if MK_SW12 is pressed
        if (key == MK_SW12 && count > 0)
        {
            if(addr > 9)
            {
                // Move to the previous log entry
                addr = addr - 10;
            }
            else
            {
                //Move to the last entry
                addr = 0x5A;
            }
            //Decrement the log counter
            count--;
        }
        // Display the log entry at the current address
        display_logs(addr);
    }
    // If there are no logs and clear flag is set, display a message
    else if (clr_flag == 1)
    {
        clcd_print("View Log", LINE1(0));
        clcd_print("No logs available", LINE2(0));
        for(unsigned long int k = 500000;k--;);
        main_f = MENU;
        CLEAR_DISP_SCREEN;
    } 
    // If MK_LONG_SW12 is pressed, return to the menu
    if (key == MK_LONG_SW12) 
    {
        CLEAR_DISP_SCREEN;
        main_f = MENU;
        addr = 0;
        count = 0;
        for (unsigned long int wait = 500000; wait--;);
    }
}
// Function to display logs on the CLCD
void display_logs(unsigned char addr)
{
    unsigned char ch, i=0;
    clcd_print("SN  TIME   EV SP", LINE1(0));
    // Loop through and display log data on the second line of the CLCD
    while(i < 16)
    {
        if(i == 0)
        {
            //Display the log entry number
            clcd_putch('0' + count, LINE2(i));
        }
        // Display dot
        else if(i == 1)
        {
            clcd_putch('.', LINE2(i));
        }
        // Display colon
        else if(i == 4 || i == 7)
        {
            clcd_putch(':', LINE2(i));
        }
        else if(i == 10 || i == 13)
        {
            clcd_putch(' ', LINE2(i));
        }
        else
        {
            // Read a character from EEPROM
            ch = read_external_eeprom(addr++);
            // Display the character on CLCD
            clcd_putch(ch, LINE2(i));
        }
        //move to the next character position
        i++;
    }
}
