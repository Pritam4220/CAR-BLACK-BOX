#include <xc.h>
#include "clcd.h"

unsigned short count1;
extern unsigned int time,sec;
void __interrupt() isr(void)
{
    if (TMR0IF == 1)
    {
        TMR0 = TMR0 + 8; // Reload Timer0 for 1 second delay
       
        if(++count1 == 20000)
        {
            //RB0 = !RB0;
            count1 = 0;
            sec++;
            if(time > 0)
            {
               time--; 
            }
        }  
        TMR0IF = 0;
    }
}
          