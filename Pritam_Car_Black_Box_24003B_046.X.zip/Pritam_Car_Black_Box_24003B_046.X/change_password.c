#include <xc.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "external_eeprom.h"
#include <string.h>

unsigned char user_pass[5], old_pass[5], new_pass[5], confirm_pass[5];
unsigned int attempt = 3, pos = 5, i = 5;
unsigned int count = 0;
unsigned int j;
unsigned long int blink_counter = 0;
unsigned char blink_state = 0;
unsigned int time = 10;
unsigned int sec = 0;
unsigned int flag = 0;
char pw_add = 0x64;
extern char main_f;
extern unsigned char originalPass[];

void change_pass(char key) 
{
    //password logic
    if (flag == 0) 
    {
        clcd_print("Enter old Passwd", LINE1(0));
        if (count < 4) 
        {
            // Adjust this value based on system clock
            if (blink_counter >= 100) 
            {
                if (blink_state == 0) 
                {
                    clcd_putch('_', LINE2(i));
                    blink_state = 1;
                } 
                else 
                {
                    clcd_putch(' ', LINE2(i)); 
                    blink_state = 0;
                }
                blink_counter = 0; 
            }
            blink_counter++;

            if (key == MK_SW11) 
            {
                clcd_putch('*', LINE2(pos));
                old_pass[pos - 5] = '1';
                count++;
                pos++;
                sec = 0;
                i++;
            } 
            else if (key == MK_SW12) 
            {
                clcd_putch('*', LINE2(pos));
                old_pass[pos - 5] = '0';
                count++;
                pos++;
                sec = 0;
                i++;
            }
        } 
        else 
        {
            CLEAR_DISP_SCREEN;
            originalPass[4] = '\0';
            old_pass[4] = '\0';
            if (strcmp(originalPass, old_pass) == 0)
            {
                //success
                count = 0;
                blink_state = 0;
                blink_counter = 0;
                i = 5, pos = 5;
                flag = 1;
            } 
            else 
            {
                //failure
                CLEAR_DISP_SCREEN;
                main_f = MENU;
                CLEAR_DISP_SCREEN;
                // Reset for next attempt
                count = 0;
                i = 5, pos = 5;
                for (j = 0; j < 4; j++) 
                {
                    // Reset each character to '0'
                    old_pass[j] = '0'; 
                }
                old_pass[j] = '\0';
            }
        }
    } 
    //Here we are going inside this condition where i enter the new password
    else if (flag == 1) 
    {
        clcd_print("Enter New Pass", LINE1(0));
        if (count < 4) 
        {
            if (blink_counter >= 100) 
            {
                if (blink_state == 0) 
                {
                    clcd_putch('_', LINE2(i));
                    blink_state = 1;
                } 
                else 
                {
                    clcd_putch(' ', LINE2(i)); 
                    blink_state = 0;
                }
                blink_counter = 0; 
            }
            blink_counter++;

            if (key == MK_SW11)
            {
                clcd_putch('*', LINE2(pos));
                new_pass[pos - 5] = '1';
                count++;
                pos++;
                sec = 0;
                i++;
            } 
            else if (key == MK_SW12) 
            {
                clcd_putch('*', LINE2(pos));
                new_pass[pos - 5] = '0';
                count++;
                pos++;
                sec = 0;
                i++;
            }

        } 
        else 
        {
            CLEAR_DISP_SCREEN;
            flag = 2;
            count = 0;
            blink_state = 0;
            blink_counter = 0;
            i = 5, pos = 5;
            old_pass[4] = '\0';

        }
    }
    //Here we are going inside this condition where i confirm the new password
    else if (flag == 2)
    {
        clcd_print("confirm Pass", LINE1(0));
        
        if (count < 4) 
        {
            if (blink_counter >= 100) 
            {
                if (blink_state == 0) 
                {
                    clcd_putch('_', LINE2(i));
                    blink_state = 1;
                }
                else
                {
                    clcd_putch(' ', LINE2(i)); 
                    blink_state = 0;
                }
                blink_counter = 0; 
            }
            blink_counter++;

            if (key == MK_SW11) 
            {
                clcd_putch('*', LINE2(pos));
                confirm_pass[pos - 5] = '1';
                count++;
                pos++;
                sec = 0;
                i++;
            } 
            else if (key == MK_SW12)
            {
                clcd_putch('*', LINE2(pos));
                confirm_pass[pos - 5] = '0';
                count++;
                pos++;
                sec = 0;
                i++;
            }
        } 
        else 
        {
            CLEAR_DISP_SCREEN;
            new_pass[4] = '\0';
            confirm_pass[4] = '\0';
            if (strcmp(new_pass, confirm_pass) == 0) 
            {
                count = 0;
                blink_state = 0;
                blink_counter = 0;
                i = 5, pos = 5;
                flag = 3;

                write_external_eeprom(0x64, new_pass[0]);
                write_external_eeprom(0x65, new_pass[1]);
                write_external_eeprom(0x66, new_pass[2]);
                write_external_eeprom(0x67, new_pass[3]);
                write_external_eeprom(0x68, new_pass[4]);


                clcd_print("changed Pass", LINE2(0));
                for (unsigned long int wait = 500000; wait--;);
                CLEAR_DISP_SCREEN;
                main_f = MENU;
            } 
            else 
            {
                //failure
                CLEAR_DISP_SCREEN;
                main_f = MENU;
                CLEAR_DISP_SCREEN;
                // Reset for next attempt
                count = 0;
                i = 5, pos = 5;
                for (j = 0; j < 4; j++) 
                {
                    // Reset each character to '0'
                    old_pass[j] = '0'; 
                }
                old_pass[j] = '\0';
            }
        }
    }
}