/*
 * File:   main.c
 * Author: Pritam kumar
 * Project: Car Black Box Project
 * Created on 11 August, 2024, 11:01 AM
 */


#include <xc.h>
#include "main.h"
#include "adc.h"
#include "clcd.h"
#include <stdio.h>
#include <stdarg.h>
#include "matrix_keypad.h"
#include "timer.h"
#include "i2c.h"
#include "ds1307.h"
#include "eeprom.h"
#include "external_eeprom.h"

char event[20];
char main_f = 0, menu_f = 0;
unsigned char clock_reg[3];
unsigned char calender_reg[4];
unsigned char real_time[9];
unsigned char date[11];
unsigned char originalPass[5] = "1100";
char set_time_flag=0;
char hour,min,sec1;
char field_pos;

void init_config() {
    //configuration of CLCD
    init_clcd();
    init_matrix_keypad();
    init_adc();
    init_timer0();
    init_i2c();
    init_ds1307();
    write_external_eeprom(0x64,originalPass[0]);
    write_external_eeprom(0x65,originalPass[1]);
    write_external_eeprom(0x66,originalPass[2]);
    write_external_eeprom(0x67,originalPass[3]);
    write_external_eeprom(0x68,'\0');
}

void main(void) {
    init_config();

    unsigned char *gear[] = {"ON", "GR", "GN", "G1", "G2", "G3", "G4", "G5", "C "};
    unsigned int index = 0, flag = 0, adc_reg_val;
    char key;

    while (1) {
        /*
         * get the time 
         * based on switch press change the event
         */
        get_time();
        key = read_switches(LEVEL_CHANGE);
        adc_reg_val = read_adc(CHANNEL4) / 10.24;

        if (key == MK_SW1) {
            //increase gear
            if (flag == 1) {
                index = 1;
            } else if (index <= 6) {
                index++;
            }
            store_event(real_time,gear[index],adc_reg_val);
            flag = 0;
        } else if (key == MK_SW2) {
            //decrease gear
            if (flag == 1) {
                index = 1;
            } else if (index > 1) {
                index--;
            }
            flag = 0;
            store_event(real_time,gear[index],adc_reg_val);
        } else if (key == MK_SW3) {
            //collision
            index = 8;
            flag = 1;
            store_event(real_time,gear[index],adc_reg_val);
        }
        if (main_f == DASHBOARD) {
            dashboard(gear[index], adc_reg_val);
            if (key == MK_SW11) {
                CLEAR_DISP_SCREEN;
                main_f = PASSWORD;
            }
        } else if (main_f == PASSWORD) {
            password(key);
        } else if (main_f == MENU) {
            menu(key);
        } else if (main_f == MENU_ENTER) {
            if (menu_f == VIEWLOG) {
                view_log(key);
            } else if (menu_f == DOWNLOADLOG) {
                download_log();
            } else if (menu_f == CLEARLOG) {
                clear_log(key);
            } else if (menu_f == SETTIME) {
                if(set_time_flag==0)
                {
                    set_time_flag=1;
                    get_time();
                    hour=((real_time[0]-'0')*10)+(real_time[1]-'0');
                    min=((real_time[3]-'0')*10)+(real_time[4]-'0');
                    sec1=((real_time[6]-'0')*10)+(real_time[7]-'0');
                    field_pos=0; 
                }
                settime(key);
            } else if (menu_f == CHANGEPASS) {
                change_pass(key);
            }
        }

    }
    return;
}
//function for  real time 
void get_time(void) {
    clock_reg[0] = read_ds1307(HOUR_ADDR);
    clock_reg[1] = read_ds1307(MIN_ADDR);
    clock_reg[2] = read_ds1307(SEC_ADDR);

    //Here i check my bit 6 is set or not 
    //This is for 12 hrs format
    if (clock_reg[0] & 0x40) {
        real_time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
        real_time[1] = '0' + (clock_reg[0] & 0x0F);
    }        //24 hrs format
    else {
        real_time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
        real_time[1] = '0' + (clock_reg[0] & 0x0F);
    }
    real_time[2] = ':';
    real_time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
    real_time[4] = '0' + (clock_reg[1] & 0x0F);
    real_time[5] = ':';
    real_time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
    real_time[7] = '0' + (clock_reg[2] & 0x0F);
    real_time[8] = '\0';
}