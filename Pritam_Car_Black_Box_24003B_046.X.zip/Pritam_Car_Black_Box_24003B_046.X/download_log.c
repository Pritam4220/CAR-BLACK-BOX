#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "uart.h"
#include "external_eeprom.h"

unsigned int dwnld_flag = 0;
extern char main_f,menu_f;
extern unsigned int store_count;

//function to download log by UART
void download_log() 
{
    //download log logic
    for(unsigned long int i=500000;i--;);
    init_uart();
    if (store_count == 0) 
    {
        puts("NO EVENTS AVAILABLE....\n\r");
    } 
    else
    {
        char ADDR;
        if(store_count<=10)
        {
            ADDR = 0;
        }
        else
        {
            ADDR = store_count%10;
        }
            
        puts(" S.NO    TIME   GEAR   SPEED  \n\n\r");
        // Loop to print each logged event
        for (char i = 0; ((i < store_count)&&(i < 10)); i++) 
        {
            // Print the serial number of the event
            puts("    ");
            // Convert index to character
            putch(i+'0');
            puts("      ");
            
            // Print the time (HH:MM:SS) from EEPROM
            putch(read_external_eeprom(( ((i+ADDR)%10) * 10) + 0));
            putch(read_external_eeprom(( ((i+ADDR)%10) * 10) + 1));
            putch(':');
            putch(read_external_eeprom(( ((i+ADDR)%10) * 10) + 2));
            putch(read_external_eeprom(( ((i+ADDR)%10) * 10) + 3));
            putch(':');
            putch(read_external_eeprom(( ((i+ADDR)%10) * 10) + 4));
            putch(read_external_eeprom(( ((i+ADDR)%10) * 10) + 5));
            puts("  ");
            
            // Print the gear status from EEPROM
            putch(read_external_eeprom(( ((i+ADDR)%10) * 10) + 6));
            putch(read_external_eeprom(( ((i+ADDR)%10) * 10) + 7));
            puts("      ");
            
             // Print the speed from EEPROM
            putch(read_external_eeprom(( ((i+ADDR)%10) * 10) + 8));
            putch(read_external_eeprom(( ((i+ADDR)%10) * 10) + 9));
            puts("\n\r");
        }
    }
    main_f = MENU;
}