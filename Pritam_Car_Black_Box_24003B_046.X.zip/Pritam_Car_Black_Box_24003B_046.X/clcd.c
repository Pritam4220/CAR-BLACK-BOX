#include <xc.h>
#include "clcd.h"

void clcd_write(unsigned char byte, unsigned char control_bit)
{
    //Here we select the register as data or instruction
	CLCD_RS = control_bit;
	CLCD_PORT = byte;

	/* Should be atleast 200ns */
    //Here we generate the clock pulse 
	CLCD_EN = HI;
	CLCD_EN = LO;
    
    //Here we set the PORTD as an input because we are reading the data
	PORT_DIR = INPUT;
    //Here we perform the read operation
	CLCD_RW = HI;

	CLCD_RS = INSTRUCTION_COMMAND;    //And here we set the RS pin to instruction
    
    //Here we check my instruction is completed or not we use method polling for RD7
	do
	{
		CLCD_EN = HI;
		CLCD_EN = LO;
	} while (CLCD_BUSY);
    
    //When checking is completed then we set R/w pin as write operation
	CLCD_RW = LO;
    //And we also set the RD7 pin as output
	PORT_DIR = OUTPUT;
}

void init_clcd()
{
	/* Set PortD as output port for CLCD data */
	TRISD = 0x00;
	/* Set PortC as output port for CLCD control */
	TRISC = TRISC & 0xF8;

	CLCD_RW = LO;

	
     /* Startup Time for the CLCD controller */
    __delay_ms(30);
    
    /* The CLCD Startup Sequence */
    //Initialize the CLCD to start given in DataSheet
    clcd_write(EIGHT_BIT_MODE, INSTRUCTION_COMMAND	);
    __delay_us(4100);
    clcd_write(EIGHT_BIT_MODE, INSTRUCTION_COMMAND	);
    __delay_us(100);
    clcd_write(EIGHT_BIT_MODE, INSTRUCTION_COMMAND	);
    __delay_us(1); 
    
    //After this we call the CLCD write function Cursor_Home is am acro where we call the CLCD_WRITE
    CURSOR_HOME;
    __delay_us(100);
    //Here we select the MATRIX 5X8
    TWO_LINE_5x8_MATRIX_8_BIT;
    __delay_us(100);
    //After this we clear the display screen
    CLEAR_DISP_SCREEN;
    __delay_us(500);
    //Here we on the display and off the cursor
    DISP_ON_AND_CURSOR_OFF;
    __delay_us(100);
}
//Here function for print the string on our clcd
void clcd_print(const unsigned char *data, unsigned char addr)
{
    //Here we call the write function 
	clcd_write(addr, INSTRUCTION_COMMAND);
	while (*data != '\0')
	{
		clcd_write(*data++, DATA_COMMAND);
	}
}

void clcd_putch(const unsigned char data, unsigned char addr)
{
	clcd_write(addr, INSTRUCTION_COMMAND);
	clcd_write(data, DATA_COMMAND);
}
